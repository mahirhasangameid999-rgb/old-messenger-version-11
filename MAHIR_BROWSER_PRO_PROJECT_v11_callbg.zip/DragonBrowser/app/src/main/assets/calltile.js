/* MAHIR BROWSER v11 - Messenger call (group + inbox): each user's own tile shows his profile pic
   as a soft white-hazy blurred background, the round pic stays in the centre, plus Fullscreen button. */
(function () {
  try {
    if (window.__dmCallTiles11) return;
    window.__dmCallTiles11 = 1;
    if (!/messenger\.com|facebook\.com/.test(location.host)) return;

    var st = document.createElement('style');
    st.textContent =
      '.dm-tile{position:relative!important;overflow:hidden!important;isolation:isolate!important;background:#ececec!important}' +
      '.dm-bg{position:absolute!important;left:-6%;top:-6%;width:112%;height:112%;z-index:0!important;background-size:cover!important;background-position:center!important;background-repeat:no-repeat!important;pointer-events:none!important;' +
      'filter:blur(7px) saturate(.75) brightness(1.1)!important;-webkit-filter:blur(7px) saturate(.75) brightness(1.1)!important}' +
      '.dm-tile::after{content:\"\";position:absolute;left:0;top:0;right:0;bottom:0;z-index:1;pointer-events:none;background:rgba(255,255,255,.58)}' +
      '.dm-tile .dm-clear{background:transparent!important;background-color:transparent!important;background-image:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}' +
      '.dm-avatar{position:relative!important;z-index:2!important;border-radius:50%!important;object-fit:cover!important;box-shadow:0 3px 14px rgba(0,0,0,.35)!important;filter:none!important}' +
      '#dm-fs{position:fixed;top:8px;right:8px;z-index:2147483647;display:flex;align-items:center;gap:6px;padding:7px 12px;border-radius:999px;' +
      'background:rgba(10,20,30,.82);color:#fff;font:600 13px/1 sans-serif;border:1.5px solid #22d3ee;box-shadow:0 2px 10px rgba(0,0,0,.5)}';
    (document.head || document.documentElement).appendChild(st);

    function R(e) { return e.getBoundingClientRect(); }

    function isAvatar(img) {
      var r = R(img);
      if (r.width < 40 || r.width > 460 || r.height < 40) return false;
      if (Math.abs(r.width - r.height) > r.width * 0.18) return false;
      var cs = getComputedStyle(img), p = img.parentElement, pcs = p ? getComputedStyle(p) : null;
      var br = cs.borderRadius + ' ' + (pcs ? pcs.borderRadius : '');
      return /50%|9999|999px|[1-9]\d{2,}px|^[2-9]\d+px/.test(br) || r.width >= 60;
    }

    function countAvatars(e) {
      var imgs = e.querySelectorAll('img'), c = 0;
      for (var i = 0; i < imgs.length; i++) if (isAvatar(imgs[i])) c++;
      return c;
    }

    // smallest ancestor that is clearly bigger than the avatar, has the avatar in its middle, and holds only this avatar
    function tileOf(img) {
      var a = R(img), acx = a.left + a.width / 2, acy = a.top + a.height / 2, e = img.parentElement, n = 0;
      while (e && e !== document.body && n++ < 7) {
        var r = R(e);
        if (r.width >= a.width * 1.5 && r.height >= a.height * 1.08) {
          var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
          var centered = Math.abs(cx - acx) < r.width * 0.12 && Math.abs(cy - acy) < r.height * 0.22;
          var ratio = r.width / r.height;
          var area = r.width * r.height, vp = innerWidth * innerHeight;
          if (!centered || ratio < 0.4 || ratio > 3.2) return null;
          if (countAvatars(e) !== 1) return null;
          if (area > vp * 1.05) return null;
          return e;
        }
        e = e.parentElement;
      }
      return null;
    }

    function hasLive(tile) {
      var v = tile.querySelectorAll('video');
      for (var i = 0; i < v.length; i++) if (v[i].videoWidth > 0 && !v[i].paused && v[i].readyState > 2) return true;
      return false;
    }

    function setup(tile, img) {
      var bg = tile.querySelector(':scope > .dm-bg');
      if (!bg) {
        bg = document.createElement('div');
        bg.className = 'dm-bg';
        tile.insertBefore(bg, tile.firstChild);
      }
      var src = img.currentSrc || img.src;
      // default (no profile pic) avatars come from Facebook's static assets / svg -> plain white tile
      var isDefault = /static\.[^\/]*fbcdn|rsrc\.php|\.svg(\?|$)|^data:image\/svg/i.test(src);
      if (bg.__src !== src) {
        bg.__src = src;
        bg.style.backgroundImage = isDefault ? 'none' : 'url("' + src.replace(/"/g, '%22') + '")';
        bg.style.backgroundColor = isDefault ? '#ffffff' : '';
      }
      tile.classList.add('dm-tile');
      img.classList.add('dm-avatar');
      var all = tile.querySelectorAll('*');
      for (var k = 0; k < all.length; k++) {
        var el = all[k];
        if (el === img || el === bg || el.className === 'dm-bg') continue;
        if (el.tagName === 'VIDEO' || el.tagName === 'IMG' || el.tagName === 'svg' || el.closest('svg')) continue;
        var ctrl = el.querySelector('button,[role=button],svg');
        if (ctrl && !el.contains(img)) continue;
        el.classList.add('dm-clear');
      }
    }

    function run() {
      var imgs = document.querySelectorAll('img');
      for (var i = 0; i < imgs.length; i++) {
        var img = imgs[i];
        if (!img.src || !isAvatar(img)) continue;
        var tile = img.closest('.dm-tile');
        if (!tile) { tile = tileOf(img); if (!tile) continue; }
        var live = hasLive(tile);
        var bg = tile.querySelector(':scope > .dm-bg');
        if (live) { if (bg) bg.style.display = 'none'; continue; }
        if (bg) bg.style.display = '';
        setup(tile, img);
      }
    }

    // ---------- Fullscreen / Exit Fullscreen ----------
    var fs = null;
    function isFs() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }
    function updateFs() {
      var inCall = /call/i.test(location.pathname);
      if (!inCall) { if (fs) { fs.remove(); fs = null; } return; }
      if (!fs) {
        fs = document.createElement('div');
        fs.id = 'dm-fs';
        fs.addEventListener('click', function (ev) {
          ev.stopPropagation();
          try {
            if (isFs()) { (document.exitFullscreen || document.webkitExitFullscreen).call(document); }
            else { var d = document.documentElement; (d.requestFullscreen || d.webkitRequestFullscreen).call(d); }
          } catch (e) {}
        }, true);
        (document.body || document.documentElement).appendChild(fs);
      }
      fs.textContent = isFs() ? '\u2715  Exit Fullscreen' : '\u26F6  Fullscreen';
    }
    document.addEventListener('fullscreenchange', updateFs);
    document.addEventListener('webkitfullscreenchange', updateFs);

    function tick() { try { run(); updateFs(); } catch (e) {} }
    var t = 0;
    new MutationObserver(function () { if (!t) t = setTimeout(function () { t = 0; tick(); }, 350); })
      .observe(document.documentElement, { childList: true, subtree: true });
    setInterval(tick, 1200);
    tick();
  } catch (e) {}
})();
